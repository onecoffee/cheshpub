var winHeight = $(window).height();
var winWidth = $(window).width();

// Задаем высоту дива

$('#background').width($(window).width());
$('#background').height($(window).height());
$('footer').width($(window).width() - 170);
$('header').width($(window).width() - 170);
$('section').height($(window).height() - 67);
$('#menu_container').height($(window).height() - 67);
$('#menu_list').height($(window).height() - 67);
$('#menu_positions').height($(window).height() - 67);
$('#first_col').height($(window).height() - 67);
$('#second_col').height($(window).height() - 67);


$(window).resize(function() {
    $('header').width($(window).width() - 170);
    $('footer').width($(window).width() - 170);
    $('#background').width($(window).width());
    $('#background').height($(window).height());
    $('section').height($(window).height() - 67);
    $('#menu_container').height($(window).height() - 67);
    $('#menu_list').height($(window).height() - 67);
    $('#menu_positions').height($(window).height() - 67);
    $('#first_col').height($(window).height() - 67);
    $('#second_col').height($(window).height() - 67);
});

$(window).trigger('resize');